MIT POKERBOT
Meet struggleBot!
By: C3 and company
